<!-- Start About fitness area -->
        <div class="about-fitness-area" id="about">
            <div class="container-fluid">
                <div class="about-fitness-left">
                    <div class="about-left-img padding-space">
                        <img src="img/about-fitness-img.png" alt="about-fitness-img">
                        <div class="overly">
                            <h3>All <span>About</span><br>Fitness</h3>
                        </div>
                    </div>
                </div>
                <div class="about-fitness-right padding-space">
                    <div class="about-single-service">
                        <div class="media service-item">
                            <div class="pull-left service-image">
                                <a href="#">
                                    <span class="flaticon-olympic-weightlifting"></span>
                                </a>
                            </div>
                            <div class="media-body service-content">
                                <h3 class="media-heading"><a href="#">Wight Lifting</a></h3>
                                <p>Simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummyy text of the printing and typesetting.</p>
                            </div>
                        </div>
                    </div>
                    <div class="about-single-service">
                        <div class="media service-item">
                            <div class="pull-left service-image">
                                <a href="#">
                                    <span class="flaticon-people"></span>
                                </a>
                            </div>
                            <div class="media-body service-content">
                                <h3 class="media-heading"><a href="#">Running</a></h3>
                                <p>Simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummyy text of the printing and typesetting.</p>
                            </div>
                        </div>
                    </div>
                    <div class="about-single-service">
                        <div class="media service-item last-item">
                            <div class="pull-left service-image">
                                <a href="#">
                                    <span class="flaticon-exercise"></span> 
                                </a>
                            </div>
                            <div class="media-body service-content">
                                <h3 class="media-heading"><a href="#">Cardio</a></h3>
                                <p>Simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummyy text of the printing and typesetting.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End About fitness area -->