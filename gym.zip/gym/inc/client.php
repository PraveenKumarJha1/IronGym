 <!-- Start what clients say area  -->
        <div class="what-client-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="section-title">
                            <h2>What Client’s Say</h2>
                        </div>
                        <div class="gym-carousel dot-control" data-loop="true" data-items="2" data-margin="15" data-autoplay="false" data-autoplay-timeout="10000" data-smart-speed="2000" data-dots="false" data-nav="true" data-nav-speed="false" data-r-x-small="1" data-r-x-small-nav="false" data-r-x-small-dots="true" data-r-x-medium="1" data-r-x-medium-nav="false" data-r-x-medium-dots="true" data-r-small="2" data-r-small-nav="false" data-r-small-dots="true" data-r-medium="2" data-r-medium-nav="false" data-r-medium-dots="true" data-r-large="2" data-r-large-nav="false" data-r-large-dots="true">
                            <div class="single-client-say">
                                <div class="pull-left client-picture">
                                    <img src="img/client1.jpg" alt="client1">
                                </div>
                                <div class="media-body client-content">
                                    <h3>Honey Jisa <span> / CEO</span></h3>
                                    <p>Lorem ipsum dolor sit amet, consectet ad elit sed diam nonummy nibh euismod tincidunt ut laoreet dolore magnaLorem ipsum dolor sit amet, consectet ad elit sed onummy.</p>
                                </div>
                            </div>
                            <div class="single-client-say">
                                <div class="pull-left client-picture">
                                    <img src="img/client2.jpg" alt="client2">
                                </div>
                                <div class="media-body client-content">
                                    <h3>Tahmid Alom <span> / Founder</span></h3>
                                    <p>Lorem ipsum dolor sit amet, consectet ad elit sed diam nonummy nibh euismod tincidunt ut laoreet dolore magnaLorem ipsum dolor sit amet, consectet ad elit sed onummy.</p>
                                </div>
                            </div>
                            <div class="single-client-say">
                                <div class="pull-left client-picture">
                                    <img src="img/client1.jpg" alt="client1">
                                </div>
                                <div class="media-body client-content">
                                    <h3>Honey Jisa <span> / CEO</span></h3>
                                    <p>Lorem ipsum dolor sit amet, consectet ad elit sed diam nonummy nibh euismod tincidunt ut laoreet dolore magnaLorem ipsum dolor sit amet, consectet ad elit sed onummy.</p>
                                </div>
                            </div>
                            <div class="single-client-say">
                                <div class="pull-left client-picture">
                                    <img src="img/client2.jpg" alt="client2">
                                </div>
                                <div class="media-body client-content">
                                    <h3>Honey Jisa <span> / CEO</span></h3>
                                    <p>Lorem ipsum dolor sit amet, consectet ad elit sed diam nonummy nibh euismod tincidunt ut laoreet dolore magnaLorem ipsum dolor sit amet, consectet ad elit sed onummy.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End what clients say area -->