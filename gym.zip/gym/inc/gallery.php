<!-- Gallery Area Start Here -->
        <div class="gallery-area" id="gallery">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                        <div class="section-title">
                            <h2>Our Gallery</h2>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                        <div class="isotop-classes-tab isotop-btn">
                            <a href="#" data-filter="*" class="current">All</a>
                            <a href="#" data-filter=".Student">Student</a>
                            <a href="#" data-filter=".Team">Team</a>
                            <a href="#" data-filter=".Gym">Gym</a>
                            <a href="#" data-filter=".Equipment">Gym Equipment</a>
                        </div>
                    </div>
                </div>
                <div class="row portfolioContainer gallery-wrapper zoom-gallery">
                    <!-- =================================== bellow is student image ============================ -->
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 Student">
                        <div class="gallery-box">
                            <img src="img/gallery/IronGym-dhanbad-student-workout-1.jpg" class="img-responsive" alt="gallery">

                            <div class="gallery-content">
                                <a href="img/gallery/IronGym-dhanbad-student-workout-1.jpg" class="elv-zoom" title="Fitness"><i class="fa fa-plus" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div> 
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 Student">
                        <div class="gallery-box">
                            <img src="img/gallery/IronGym-dhanbad-student-workout-2.jpg" class="img-responsive" alt="gallery">

                            <div class="gallery-content">
                                <a href="img/gallery/IronGym-dhanbad-student-workout-2.jpg" class="elv-zoom" title="Fitness"><i class="fa fa-plus" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div> 
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 Student">
                        <div class="gallery-box">
                            <img src="img/gallery/IronGym-dhanbad-student-workout-3.jpg" class="img-responsive" alt="gallery">

                            <div class="gallery-content">
                                <a href="img/gallery/IronGym-dhanbad-student-workout-3.jpg" class="elv-zoom" title="Fitness"><i class="fa fa-plus" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div> 
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 Student">
                        <div class="gallery-box" >
                            <img src="img/gallery/IronGym-dhanbad-student-workout-5.jpg" class="img-responsive" alt="gallery">

                            <div class="gallery-content">
                                <a href="img/gallery/IronGym-dhanbad-student-workout-5.jpg" class="elv-zoom" title="Fitness"><i class="fa fa-plus" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div> 
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 Student">
                        <div class="gallery-box">
                            <img src="img/gallery/IronGym-dhanbad-student-workout-6.jpg" class="img-responsive" alt="gallery">

                            <div class="gallery-content">
                                <a href="img/gallery/IronGym-dhanbad-student-workout-6.jpg" class="elv-zoom" title="Fitness"><i class="fa fa-plus" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div> 
                    <!-- =================================== bellow is Team image ============================ -->
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 Team">
                        <div class="gallery-box">
                            <img src="img/gallery/IronGym-dhanbad-team-1.jpg" class="img-responsive" alt="gallery">

                            <div class="gallery-content">
                                <a href="img/gallery/IronGym-dhanbad-team-1.jpg" class="elv-zoom" title="Fitness"><i class="fa fa-plus" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div> 
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 Team">
                        <div class="gallery-box">
                            <img src="img/gallery/IronGym-dhanbad-team-2.jpg" class="img-responsive" alt="gallery">

                            <div class="gallery-content">
                                <a href="img/gallery/IronGym-dhanbad-team-2.jpg" class="elv-zoom" title="Fitness"><i class="fa fa-plus" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 Team">
                        <div class="gallery-box">
                            <img src="img/gallery/IronGym-dhanbad-team-3.jpg" class="img-responsive" alt="gallery">

                            <div class="gallery-content">
                                <a href="img/gallery/IronGym-dhanbad-team-3.jpg" class="elv-zoom" title="Fitness"><i class="fa fa-plus" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 Team">
                        <div class="gallery-box">
                            <img src="img/gallery/IronGym-dhanbad-team-4.jpg" class="img-responsive" alt="gallery">

                            <div class="gallery-content">
                                <a href="img/gallery/IronGym-dhanbad-team-4.jpg" class="elv-zoom" title="Fitness"><i class="fa fa-plus" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>



                    <!-- =================================== bellow is Gym image ============================ -->
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 Gym">
                        <div class="gallery-box">
                            <img src="img/gallery/KUSUMBIHAR-NEAR-KIDZ-CARE-SCHOOL-DHANBAD-Jharkhand.jpg" class="img-responsive" alt="gallery">

                            <div class="gallery-content">
                                <a href="img/gallery/KUSUMBIHAR-NEAR-KIDZ-CARE-SCHOOL-DHANBAD-Jharkhand.jpg" class="elv-zoom" title="Fitness"><i class="fa fa-plus" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 Gym">
                        <div class="gallery-box">
                            <img src="img/gallery/MUSKAN-COMPLEX-NAYABAZAR-Dhanbad-Jharkhand.jpg" class="img-responsive" alt="gallery">

                            <div class="gallery-content">
                                <a href="img/gallery/MUSKAN-COMPLEX-NAYABAZAR-Dhanbad-Jharkhand.jpg" class="elv-zoom" title="Fitness"><i class="fa fa-plus" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>






                    <!-- =================================== bellow is Gym Equipment image ============================ -->
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 Equipment">
                        <div class="gallery-box">
                            <img src="img/gallery/ironGym-dhanbad-1.jpg" class="img-responsive" alt="gallery">

                            <div class="gallery-content">
                                <a href="img/gallery/ironGym-dhanbad-1.jpg" class="elv-zoom" title="Fitness"><i class="fa fa-plus" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 Equipment">
                        <div class="gallery-box">
                            <img src="img/gallery/ironGym-dhanbad-2.jpg" class="img-responsive" alt="gallery">
                            <div class="gallery-content">
                                <a href="img/gallery/ironGym-dhanbad-2.jpg" class="elv-zoom" title="Push Up"><i class="fa fa-plus" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 Equipment">
                        <div class="gallery-box">
                            <img src="img/gallery/ironGym-dhanbad-3.jpg" class="img-responsive" alt="gallery">
                            <div class="gallery-content">
                                <a href="img/gallery/ironGym-dhanbad-3.jpg" class="elv-zoom" title="Weight Lifting"><i class="fa fa-plus" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 Equipment">
                        <div class="gallery-box">
                            <img src="img/gallery/ironGym-dhanbad-4.jpg" class="img-responsive" alt="gallery">
                            <div class="gallery-content">
                                <a href="img/gallery/ironGym-dhanbad-4.jpg" class="elv-zoom" title="Free Hand"><i class="fa fa-plus" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 Equipment">
                        <div class="gallery-box">
                            <img src="img/gallery/ironGym-dhanbad-5.jpg" class="img-responsive" alt="gallery">
                            <div class="gallery-content">
                                <a href="img/gallery/ironGym-dhanbad-5.jpg" class="elv-zoom" title="Body Building"><i class="fa fa-plus" aria-hidden="true"></i></a>
                            </div>
                        </div>
  
                </div>
            </div>
        </div>
        <!-- Gallery Area End Here -->





        <!-- Start Fitness class summer area -->
        <div class="fitness-summer-area padding-space">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="fitness-summer">
                            <div class="fitness-content">
                                <!-- <h3><span>Fitness Classes</span> This Summer.</h3> --> 
                                <p>Pay Now and
                                    <br> Get <span>Membership</span> Discount</p>
                                <a class="custom-button" data-title="Become A Member" href="#">Become A Member</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Fitness class summer area