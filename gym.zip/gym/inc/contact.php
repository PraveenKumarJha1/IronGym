 <!-- Start Contact page area -->
        <div class="contact-us-area" id="contact">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 col-md-5 col-sm-5">
                        <form class="form-horizontal contact-form" id="contact-form" role="form">
                            <fieldset>
                                <!-- Form Name -->
                                <legend>Contact Form</legend>
                                <!-- Text input-->
                                <div class="form-group">
                                    <label class="control-label pull-left"><i class="fa fa-user" aria-hidden="true"></i></label>
                                    <div class="media-body">
                                        <input id="form-name" name="textinput" placeholder="Name" class="form-control input-md" type="text" data-error="Name field is required" required>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <!-- Text input-->
                                <div class="form-group">
                                    <label class="control-label pull-left"><i class="fa fa-envelope-o" aria-hidden="true"></i></label>
                                    <div class="media-body">
                                        <input id="form-email" name="textinput" placeholder="E-mail" class="form-control input-md" type="text" data-error="E-mail field is required" required>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <!-- Text input-->
                                <div class="form-group">
                                    <label class="control-label pull-left"><i class="fa fa-phone" aria-hidden="true"></i></label>
                                    <div class="media-body">
                                        <input id="form-phone" name="textinput" placeholder="Phone" class="form-control input-md" type="text" data-error="Phone field is required" required>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <!-- Textarea -->
                                <div class="form-group">
                                    <label class="control-label arealebel pull-left"><i class="fa fa-envelope" aria-hidden="true"></i></label>
                                    <div class="media-body">
                                        <textarea class="textarea form-control" id="form-message" name="textarea" placeholder="Message" data-error="Message field is required" required></textarea>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <!-- Button -->
                                <div class="form-group send-button">
                                    <div class="media-body">
                                        <button type="submit" class="btn-read-more-fill btn-send">Send Message</button>
                                    </div>
                                </div>
                                <div class='form-response'></div>
                            </fieldset>
                        </form>
                    </div>
                    <div class="col-lg-7 col-md-7 col-sm-7">
                        <!-- <div id="googleMap" style="width:100%;height:485px;"></div> -->
                        <div> 
                                <h1>Our Gym Address</h1>
                                <ul class="nav nav-tabs">
                                    <li class="active"><a data-toggle="tab" href="#home">IronGym-1</a></li>
                                    <li><a data-toggle="tab" href="#menu1">IronGym-2</a></li>
                                    <li><a data-toggle="tab" href="#menu2">IronGym-3</a></li>
                                    <li><a data-toggle="tab" href="#menu3">IronGym-4</a></li>
                                  </ul>

                                  <div class="tab-content">
                                    <div id="home" class="tab-pane fade in active">
                                      <h3>IronGym-1</h3>
                                     <div class="corporate-address">
                                        <ul>
                                            <li><i class="fa fa-send" aria-hidden="true"></i>MUSKAN COMPLEX NAYABAZAR Dhanbad, Jharkhand, India</li>
                                            <li><i class="fa fa-phone" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-envelope-o" aria-hidden="true"></i></li> 
                                        </ul>
                                        
                                     </div>
                                    </div>
                                    <div id="menu1" class="tab-pane fade">
                                      <h3>IronGym-2</h3>
                                      <div class="corporate-address">
                                        <ul>
                                            <li><i class="fa fa-send" aria-hidden="true"></i>KUSUMBIHAR NEAR KIDZ CARE SCHOOL DHANBAD , Jharkhand, India</li>
                                            <li><i class="fa fa-phone" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-envelope-o" aria-hidden="true"></i></li> 
                                        </ul>

                                     </div>
                                    </div>
                                    <div id="menu2" class="tab-pane fade">
                                      <h3>IronGym-3</h3>
                                      <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
                                    </div>
                                    <div id="menu3" class="tab-pane fade">
                                      <h3>IronGym-4</h3>
                                      <p>Eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
                                    </div>
                                  </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Contact page area -->