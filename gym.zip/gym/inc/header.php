       <!-- Start Header area -->

       <header class="main-header header-style1" id="sticker">
            <!-- Start Header Top Area -->
            <div class="header-top-area">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-2 col-md-2 col-sm-2">
                            <div class="logo-area" style="position:absolute">
                                <a href="index.php"><img src="img/IronGym_Dhanbad_logo.png" alt="IronGym logo"></a>
                            </div>
                        </div>
                        <div class="col-lg-9 col-md-9 col-sm-10">
                            <div class="main-menu">
                                <nav>
                                    <ul id="nav">
                                        <li class="current"><a href="index.php">Home</a></li>
                                        <li><a href="#about">About</a></li>
                                        <!-- <li><a href="#classes">Classes</a></li> -->
                                        <li><a href="#schedule">Schedule</a></li>
                                        <li><a href="#trainers">Trainers</a></li>
                                        <li><a href="#price">Price</a></li>
                                        <li><a href="#gallery">gallery</a></li>
                                        <!-- <li><a href="#news">News</a></li> -->
                                        <li><a href="#contact">Contact</a></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="col-lg-1 col-md-1 hidden-sm">
                            <div class="header-top-right">
                             
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End header Top Area -->
            <!-- mobile-menu-area start -->
            <div class="mobile-menu-area">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="mobile-menu">
                                <nav id="dropdown">
                                    <ul>
                                        <li class="current"><a href="index.php">Home</a></li>
                                        <li><a href="#about">About</a></li>
                                        <!-- <li><a href="#classes">Classes</a></li> -->
                                        <li><a href="#schedule">Schedule</a></li>
                                        <li><a href="#trainers">Trainers</a></li>
                                        <li><a href="#price">Price</a></li>
                                        <li><a href="#contact">Contact</a></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- mobile-menu-area end -->
        </header>

          <!-- End Header area -->