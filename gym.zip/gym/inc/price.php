        <!-- Start Price Table area -->
        <div class="price-table-area" id="price">
            <div class="container">
                <div class="section-title">
                    <h2>Our Pricing Table</h2>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 hvr-float-shadow">
                        <div class="price-table-box">
                            <span>Basic</span>
                            <!-- <h3>₹1,500</h3>
                            <span>+</span> -->                            
                            <h3>₹800<span>/month</span></h3><span>+</span><span>Addmission Fee</span>
                            <ul>
                                <li>Free Hand</li>
                                <li>Gym Fitness</li>
                                <li>Running</li>
                                <li>Body Building</li>
                                <li>-------</li>
                            </ul>
                            <a class="custom-button" data-title="Become A Member" href="#">Details</a>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 hvr-float-shadow">
                        <div class="price-table-box">
                            <span>Standard</span>
                            <!-- <h3>$199<span>/Half</span></h3> -->
                            <h3>₹5,000<span>/half-yearly</span></h3><span>+</span><span>Addmission Fee</span>
                            <ul>
                                <li>Free Hand</li>
                                <li>Gym Fitness</li>
                                <li>Running</li>
                                <li>Body Building</li>
                                <li>-------</li>
                            </ul>
                            <a class="custom-button" data-title="Become A Member" href="#">Details</a>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 hvr-float-shadow">
                        <div class="price-table-box">
                            <span>Platinum</span>
                            <h3>₹9,000<span>/yearly</span></h3><span>+</span><span>Addmission Fee</span>
                            <ul >
                                <li>Free Hand</li>
                                <li>Gym Fitness</li>
                                <li>Running</li>
                                <li>Body Building</li>
                                <li>-------</li>
                            </ul>
                            <a class="custom-button" data-title="Become A Member" href="#">Details</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Price Table area -->