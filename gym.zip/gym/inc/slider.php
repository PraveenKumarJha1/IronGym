 <!-- Start slider area  -->

<div class="slider-area slider-top-space-header1 slider1-caption">
            <div class="bend niceties preview-2">
                <div id="ensign-nivoslider" class="slides">
                    <img src="img/slides/slide1.jpg" alt="image" title="#slider-direction-1" />
                    <img src="img/slides/slide2.jpg" alt="image" title="#slider-direction-1" />
                    <img src="img/slides/slide1.jpg" alt="image" title="#slider-direction-1" />
                </div>
                <!-- direction 1 -->
                <div id="slider-direction-1" class="t-cn slider-direction">
                    <!-- <div class="slider-progress"></div> -->
                    <div class="slider-content t-cn s-tb slider-1">
                        <div class="title-container s-tb-c title-compress">
                            <div data-wow-delay="0.1s" data-wow-duration="1s" class="tp-caption big-title rs-title customin customout bg-sld-cp-primary ">Build <span>Your</span> Body <span>Strong</span>
                            </div>
                            <div data-wow-delay="0.2s" data-wow-duration="2s" class="tp-caption small-content customin customout rs-title-small bg-sld-cp-primary tp-resizeme rs-parallaxlevel-0 ">
                                Simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the idustry's standard type specimen book. It has survived not only five centuries, bu
                            </div>
                            <div class="button">
                                <a href="#" class="btn custom-button" data-title="Join With Us">Join With Us</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

         <!-- End slider area-->
