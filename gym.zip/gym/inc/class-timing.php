s
<!-- Start class schedule area -->
        <div class="class-schedule" id="schedule">
            <div class="container" style="padding-bottom: 60px;">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="section-title">
                            <h2>Class ScheDule</h2>
                        </div>
                        <div class="class-schedule-wrap">
                            <!-- Tabs -->
                            <ul id="myTab" class="nav nav-tabs">
                                <li class="active"><a href="#monday" data-toggle="tab">Monday</a></li>
                                <li><a href="#tuesday" data-toggle="tab">Tuesday</a></li>
                                <li><a href="#wednesday" data-toggle="tab">Wednesday</a></li>
                                <li><a href="#thursday" data-toggle="tab">Thursday</a></li>
                                <li><a href="#friday" data-toggle="tab">Friday</a></li>
                                <li><a href="#saturday" data-toggle="tab">Saturday</a></li>
                                <li><a href="#sunday" data-toggle="tab">Sunday</a></li>
                            </ul>
                            <div id="myTabContent" class="tab-content class-schedule-tab">
                                <div class="tab-pane fade in active" id="Morning">
                                    <ul class="odd">
                                        <li>Boys & Girls</li>
                                        <li>6.00 AM - 9.30 AM</li>
                                        <li>Morning</li>
                                        <li><a href="#">Join Us</a></li>
                                    </ul>
                                    <ul class="even">
                                        <li>Only Girls</li>
                                        <li>09.30 AM - 11.00 Am</li>
                                        <li>Morning</li>
                                        <li><a href="#">Join Us</a></li>
                                    </ul>
                                    <ul class="odd">
                                        <li>Boys & Girls</li>
                                        <li>04.00 PM - 9.00 PM</li>
                                        <li>Evening</li>
                                        <li><a href="#">Join Us</a></li>
                                    </ul>
                                    
                                </div>
                                <div class="tab-pane fade" id="tuesday">
									<ul class="odd">
                                        <li>Boys & Girls</li>
                                        <li>6.00 AM - 9.30 AM</li>
                                        <li>Morning</li>
                                        <li><a href="#">Join Us</a></li>
                                    </ul>
                                    <ul class="even">
                                        <li>Only Girls</li>
                                        <li>09.30 AM - 11.00 Am</li>
                                        <li>Morning</li>
                                        <li><a href="#" >Join Us</a></li>
                                    </ul>
                                    <ul class="odd">
                                        <li>Boys & Girls</li>
                                        <li>04.00 PM - 9.00 PM</li>
                                        <li>Evening</li>
                                        <li><a href="#">Join Us</a></li>
                                    </ul>                                </div>
                                <div class="tab-pane fade" id="wednesday">
                                    
                                	<ul class="odd">
                                        <li>Boys & Girls</li>
                                        <li>6.00 AM - 9.30 AM</li>
                                        <li>Morning</li>
                                        <li><a href="#">Join Us</a></li>
                                    </ul>
                                    <ul class="even">
                                        <li>Only Girls</li>
                                        <li>09.30 AM - 11.00 Am</li>
                                        <li>Morning</li>
                                        <li><a href="#">Join Us</a></li>
                                    </ul>
                                    <ul class="odd">
                                        <li>Boys & Girls</li>
                                        <li>04.00 PM - 9.00 PM</li>
                                        <li>Evening</li>
                                        <li><a href="#">Join Us</a></li>
                                    </ul>

                                </div>
                                <div class="tab-pane fade" id="thursday">
                                    <ul class="odd">
                                        <li>Boys & Girls</li>
                                        <li>6.00 AM - 9.30 AM</li>
                                        <li>Morning</li>
                                        <li><a href="#">Join Us</a></li>
                                    </ul>
                                    <ul class="even">
                                        <li>Only Girls</li>
                                        <li>09.30 AM - 11.00 Am</li>
                                        <li>Morning</li>
                                        <li><a href="#">Join Us</a></li>
                                    </ul>
                                    <ul class="odd">
                                        <li>Boys & Girls</li>
                                        <li>04.00 PM - 9.00 PM</li>
                                        <li>Evening</li>
                                        <li><a href="#">Join Us</a></li>
                                    </ul>

                                </div>
                                <div class="tab-pane fade" id="friday">
                                	<ul class="odd">
                                        <li>Boys & Girls</li>
                                        <li>6.00 AM - 9.30 AM</li>
                                        <li>Morning</li>
                                        <li><a href="#">Join Us</a></li>
                                    </ul>
                                    <ul class="even">
                                        <li>Only Girls</li>
                                        <li>09.30 AM - 11.00 Am</li>
                                        <li>Morning</li>
                                        <li><a href="#">Join Us</a></li>
                                    </ul>
                                    <ul class="odd">
                                        <li>Boys & Girls</li>
                                        <li>04.00 PM - 9.00 PM</li>
                                        <li>Evening</li>
                                        <li><a href="#">Join Us</a></li>
                                    </ul>
                                    
                                </div>
                                <div class="tab-pane fade" id="saturday">
                                	<ul class="odd">
                                        <li>Boys & Girls</li>
                                        <li>6.00 AM - 9.30 AM</li>
                                        <li>Morning</li>
                                        <li><a href="#">Join Us</a></li>
                                    </ul>
                                    <ul class="even">
                                        <li>Only Girls</li>
                                        <li>09.30 AM - 11.00 Am</li>
                                        <li>Morning</li>
                                        <li><a href="#">Join Us</a></li>
                                    </ul>
                                    <ul class="odd">
                                        <li>Boys & Girls</li>
                                        <li>04.00 PM - 9.00 PM</li>
                                        <li>Evening</li>
                                        <li><a href="#">Join Us</a></li>
                                    </ul>
                                   
                                </div>
                                <div class="tab-pane fade" id="sunday">
                                  
                              <ul class="text-center odd"><li>Closed</li></ul>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End class schedule area -->
