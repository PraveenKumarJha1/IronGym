 <!-- Start Expert trainers area -->
        <div class="expert-trainer-area nav-on-hover" id="trainers">
            <div class="container">
                <div class="section-title">
                    <h2>Expert Trainers</h2>
                </div>
            </div>
            <div class="container">
                <div class="gym-carousel nav-control-top" data-loop="true" data-items="3" data-margin="15" data-autoplay="false" data-autoplay-timeout="10000" data-smart-speed="2000" data-dots="false" data-nav="true" data-nav-speed="false" data-r-x-small="1" data-r-x-small-nav="true" data-r-x-small-dots="false" data-r-x-medium="1" data-r-x-medium-nav="true" data-r-x-medium-dots="false" data-r-small="2" data-r-small-nav="true" data-r-small-dots="false" data-r-medium="3" data-r-medium-nav="true" data-r-medium-dots="false" data-r-large="3" data-r-large-nav="true" data-r-large-dots="false">
                    <div class="single-trainer-item">
                        <div class="trainer-item">
                            <div class="trainer-img">
                                <img src="img/trainers/IronGym-Trainer-Roshan-Jha.jpeg" alt="trainer1">
                                <div class="social-overly">
                                    <ul>
                                        <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                        <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                        <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                    </ul>
                                </div>
                                <div class="trainer-overly">
                                    <h3><a href="">Roshan Jha</a></h3>
                                    <span class="builder">Body Builder</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="single-trainer-item">
                        <div class="trainer-item">
                            <div class="trainer-img">
                                <img src="img/trainers/IronGym-Trainer-Vickky-Singh.jpeg" alt="trainer2">
                                <div class="social-overly">
                                    <ul>
                                        <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                        <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                        <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                    </ul>
                                </div>
                                <div class="trainer-overly">
                                    <h3><a href="">Vickky Singh</a></h3>
                                    <span class="builder">Body Building</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="single-trainer-item">
                        <div class="trainer-item">
                            <div class="trainer-img">
                                <img src="img/trainers/IronGym-Trainer-Mintu-Jee.jpeg" alt="trainer3">
                                <div class="social-overly">
                                    <ul>
                                        <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                        <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                        <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                    </ul>
                                </div>
                                <div class="trainer-overly">
                                    <h3><a href="">Mintu Jee</a></h3>
                                    <span class="builder">Weight Lifting</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="single-trainer-item">
                        <div class="trainer-item">
                            <div class="trainer-img">
                                <img src="img/trainers/IronGym-Trainer-Brajesh.jpeg" alt="trainer4">
                                <div class="social-overly">
                                    <ul>
                                        <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                        <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                        <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                    </ul>
                                </div>
                                <div class="trainer-overly">
                                    <h3><a href="">Brajesh</a></h3>
                                    <span class="builder">Body Builder</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Expert tainers area -->